-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         12.0.2-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla banco.auth_group: ~0 rows (aproximadamente)

-- Volcando datos para la tabla banco.auth_group_permissions: ~0 rows (aproximadamente)

-- Volcando datos para la tabla banco.auth_permission: ~36 rows (aproximadamente)
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
	(1, 'Can add log entry', 1, 'add_logentry'),
	(2, 'Can change log entry', 1, 'change_logentry'),
	(3, 'Can delete log entry', 1, 'delete_logentry'),
	(4, 'Can view log entry', 1, 'view_logentry'),
	(5, 'Can add permission', 2, 'add_permission'),
	(6, 'Can change permission', 2, 'change_permission'),
	(7, 'Can delete permission', 2, 'delete_permission'),
	(8, 'Can view permission', 2, 'view_permission'),
	(9, 'Can add group', 3, 'add_group'),
	(10, 'Can change group', 3, 'change_group'),
	(11, 'Can delete group', 3, 'delete_group'),
	(12, 'Can view group', 3, 'view_group'),
	(13, 'Can add content type', 4, 'add_contenttype'),
	(14, 'Can change content type', 4, 'change_contenttype'),
	(15, 'Can delete content type', 4, 'delete_contenttype'),
	(16, 'Can view content type', 4, 'view_contenttype'),
	(17, 'Can add session', 5, 'add_session'),
	(18, 'Can change session', 5, 'change_session'),
	(19, 'Can delete session', 5, 'delete_session'),
	(20, 'Can view session', 5, 'view_session'),
	(21, 'Can add task', 6, 'add_task'),
	(22, 'Can change task', 6, 'change_task'),
	(23, 'Can delete task', 6, 'delete_task'),
	(24, 'Can view task', 6, 'view_task'),
	(25, 'Can add user', 7, 'add_customuser'),
	(26, 'Can change user', 7, 'change_customuser'),
	(27, 'Can delete user', 7, 'delete_customuser'),
	(28, 'Can view user', 7, 'view_customuser'),
	(29, 'Can add cuenta', 8, 'add_cuenta'),
	(30, 'Can change cuenta', 8, 'change_cuenta'),
	(31, 'Can delete cuenta', 8, 'delete_cuenta'),
	(32, 'Can view cuenta', 8, 'view_cuenta'),
	(33, 'Can add transaccion', 9, 'add_transaccion'),
	(34, 'Can change transaccion', 9, 'change_transaccion'),
	(35, 'Can delete transaccion', 9, 'delete_transaccion'),
	(36, 'Can view transaccion', 9, 'view_transaccion');

-- Volcando datos para la tabla banco.banco_cuenta: ~4 rows (aproximadamente)
INSERT INTO `banco_cuenta` (`id_cuenta`, `tipo_cuenta`, `valor_inicial`, `usuario_id`) VALUES
	(1, 'AHORROS', 250000.00, 2),
	(2, 'CDT', 150000.00, 2),
	(3, 'CORRIENTE', 350000.00, 2),
	(5, 'AHORROS', 500000.00, 3);

-- Volcando datos para la tabla banco.banco_customuser: ~4 rows (aproximadamente)
INSERT INTO `banco_customuser` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`, `apellido`, `numero_identificacion`) VALUES
	(1, 'pbkdf2_sha256$1000000$HtqFp8Fx74FsIebPriNWFM$+IPwlLg6uU6cQptxb0YVrkipBNb5qOIv75xg/93GzYk=', '2025-10-24 23:21:57.019998', 1, 'admin', '', '', 'admin@admin.com', 1, 1, '2025-10-24 23:10:34.585261', '', ''),
	(2, 'pbkdf2_sha256$1000000$RQR4eyjYPak9Tzx46lCgK2$rCiRYVC5C5ZLZnJyVpoqYa9kF9U8S48R6vtUl2H17rs=', NULL, 0, 'carlos', 'Carls', 'gomez', 'carlos@carls.com', 0, 1, '2025-10-24 23:22:59.552007', 'perez', '20202530'),
	(3, 'pbkdf2_sha256$1000000$xrUez2E5yc7Ly23FzbqZKM$EhMk1kWu4ldQNis3OQWwZ5jFes9D5+txo/Blc7YpAcg=', NULL, 0, 'carls', 'Carls', 'Jhons', 'carls@carls.com', 0, 1, '2025-11-07 02:53:33.336857', 'Segundo', '20202520'),
	(4, 'pbkdf2_sha256$1000000$iny6DFH5YuQuZhTMkxsjoV$Ba78iHEPR5Ni3Rf7TR07rW9M0+RaNCqvM8n6y6MIACc=', NULL, 0, 'JuanesCard', 'Juanes', 'Ceballos', 'juanes@juanes.com', 0, 1, '2025-11-07 12:55:09.236603', 'Oteca', '78945685');

-- Volcando datos para la tabla banco.banco_customuser_groups: ~0 rows (aproximadamente)

-- Volcando datos para la tabla banco.banco_customuser_user_permissions: ~0 rows (aproximadamente)

-- Volcando datos para la tabla banco.banco_transaccion: ~4 rows (aproximadamente)
INSERT INTO `banco_transaccion` (`id_transaccion`, `tipo_transaccion`, `monto`, `cuenta_id`) VALUES
	(1, 'CONSIGNACION', 50000.00, 1),
	(2, 'RETIRO', 50000.00, 2),
	(3, 'CONSIGNACION', 50000.00, 2),
	(5, 'RETIRO', 100000.00, 5);

-- Volcando datos para la tabla banco.django_admin_log: ~3 rows (aproximadamente)
INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
	(1, '2025-10-24 23:23:00.628421', '2', 'Carlitos - Perez', 1, '[{"added": {}}]', 7, 1),
	(2, '2025-10-24 23:23:42.327411', '1', 'AHORROS - Carlitos - 200000', 1, '[{"added": {}}]', 8, 1),
	(3, '2025-10-24 23:23:54.737300', '1', 'CONSIGNACION - 50000', 1, '[{"added": {}}]', 9, 1);

-- Volcando datos para la tabla banco.django_content_type: ~9 rows (aproximadamente)
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
	(1, 'admin', 'logentry'),
	(2, 'auth', 'permission'),
	(3, 'auth', 'group'),
	(4, 'contenttypes', 'contenttype'),
	(5, 'sessions', 'session'),
	(6, 'tasks', 'task'),
	(7, 'banco', 'customuser'),
	(8, 'banco', 'cuenta'),
	(9, 'banco', 'transaccion');

-- Volcando datos para la tabla banco.django_migrations: ~20 rows (aproximadamente)
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
	(1, 'contenttypes', '0001_initial', '2025-10-24 23:10:02.837199'),
	(2, 'contenttypes', '0002_remove_content_type_name', '2025-10-24 23:10:02.881988'),
	(3, 'auth', '0001_initial', '2025-10-24 23:10:03.018938'),
	(4, 'auth', '0002_alter_permission_name_max_length', '2025-10-24 23:10:03.050251'),
	(5, 'auth', '0003_alter_user_email_max_length', '2025-10-24 23:10:03.058083'),
	(6, 'auth', '0004_alter_user_username_opts', '2025-10-24 23:10:03.063628'),
	(7, 'auth', '0005_alter_user_last_login_null', '2025-10-24 23:10:03.068963'),
	(8, 'auth', '0006_require_contenttypes_0002', '2025-10-24 23:10:03.070893'),
	(9, 'auth', '0007_alter_validators_add_error_messages', '2025-10-24 23:10:03.076811'),
	(10, 'auth', '0008_alter_user_username_max_length', '2025-10-24 23:10:03.083025'),
	(11, 'auth', '0009_alter_user_last_name_max_length', '2025-10-24 23:10:03.088350'),
	(12, 'auth', '0010_alter_group_name_max_length', '2025-10-24 23:10:03.107264'),
	(13, 'auth', '0011_update_proxy_permissions', '2025-10-24 23:10:03.115109'),
	(14, 'auth', '0012_alter_user_first_name_max_length', '2025-10-24 23:10:03.120497'),
	(15, 'banco', '0001_initial', '2025-10-24 23:10:03.346378'),
	(16, 'admin', '0001_initial', '2025-10-24 23:10:03.433376'),
	(17, 'admin', '0002_logentry_remove_auto_add', '2025-10-24 23:10:03.449555'),
	(18, 'admin', '0003_logentry_add_action_flag_choices', '2025-10-24 23:10:03.459653'),
	(19, 'sessions', '0001_initial', '2025-10-24 23:10:03.491762'),
	(20, 'tasks', '0001_initial', '2025-10-24 23:10:03.534981');

-- Volcando datos para la tabla banco.django_session: ~1 rows (aproximadamente)
INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
	('q1v7wt2s86iw9jk5qb6sq41bg5tmjku1', '.eJxVjDsOwjAQBe_iGlm2F_8o6TmDtd51cAA5UpxUiLuTSCmgfTPz3iLhutS09jKnkcVFaHH63TLSs7Qd8APbfZI0tWUes9wVedAubxOX1_Vw_w4q9rrViAzaFKYYFBByCcp5D_GsI7qNEUYL0TgeDJB2GTxHbRVYZzQPFMTnC-nYN58:1vCR6b:y89KHDqdyP-L6HLKc0ZJLGHeW3DiqpFWdecKPXkTQSs', '2025-11-07 23:21:57.023307');

-- Volcando datos para la tabla banco.tasks_task: ~0 rows (aproximadamente)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
